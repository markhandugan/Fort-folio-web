// Scroll-reveal
const obs = new IntersectionObserver(entries => {
    entries.forEach((e, i) => {
        if (e.isIntersecting) setTimeout(() => e.target.classList.add('visible'), i * 65);
    });
}, { threshold: 0.08 });
document.querySelectorAll('.reveal').forEach(el => obs.observe(el));

// Active nav
const secs = document.querySelectorAll('section');
const links = document.querySelectorAll('.nav-links a');
window.addEventListener('scroll', () => {
    let cur = '';
    secs.forEach(s => { if (window.scrollY >= s.offsetTop - 220) cur = s.id; });
    links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === `#${cur}`));
});

// Form submit
function sendMsg(e) {
    e.preventDefault();
    const btn = document.getElementById('sendBtn');
    btn.textContent = '✓ Message Sent!';
    btn.style.background = 'linear-gradient(135deg, #4ade80, #22c55e)';
    setTimeout(() => {
        btn.textContent = 'Send Message';
        btn.style.background = '';
        e.target.reset();
    }, 3000);
}